#version 430 core

void main()
{

}
